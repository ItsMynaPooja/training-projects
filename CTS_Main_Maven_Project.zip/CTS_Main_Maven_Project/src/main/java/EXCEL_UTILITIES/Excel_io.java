package EXCEL_UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_io {
	
	public static String filename="src\\test\\resources\\TESTDATA\\Marsproj.xlsx",
			Sheetname="sheet1";
	public static int r_no=0,c_no;
	public static String[][] testdata;
	
	public static void get_test_data()
	{
		testdata=new String[1][2];
		
		  
		try {
			System.out.println("in excel");
			for(c_no=0;c_no<=1;c_no++)
			{
			File f=new File(filename);
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(Sheetname);
			XSSFRow row=sh.getRow(r_no);
			XSSFCell cell1=row.getCell(c_no);
			testdata[r_no][c_no]=cell1.getStringCellValue();
			System.out.println("r1: "+testdata[r_no][c_no]);
			
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
}
