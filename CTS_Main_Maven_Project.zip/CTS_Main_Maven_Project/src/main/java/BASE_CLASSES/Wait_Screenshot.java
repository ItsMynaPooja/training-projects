package BASE_CLASSES;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Wait_Screenshot 
{
	static int counter;
	WebDriver dr;
	
	public Wait_Screenshot(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebElement waitForElement(By locator, int timeout)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			System.out.println("element located");
			return element;
		}catch(Exception e) {
			System.out.println("element not located" + e);
		}
		return null;
	}

	public WebElement elementToBeClickable(By locator, int timeout)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			System.out.println("element located");
			return element;
		}catch(Exception e) {
			System.out.println("element not located" + e);
		}
		return null;
	}
	
	
	public void get_screenshot()
	{
		String path="src\\test\\resources\\SCREENSHOTS\\sss";
		String filename=counter+ ".png";
		File f1 =((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+filename);
		
		
			try {
				FileUtils.copyFile(f1, f2);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		counter++;
		
	

}
}
