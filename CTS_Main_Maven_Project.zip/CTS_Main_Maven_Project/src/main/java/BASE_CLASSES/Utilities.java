package BASE_CLASSES;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import EXCEL_UTILITIES.Excel_io;

public class Utilities extends Excel_io{
	
	protected WebDriver dr;
	
	
	public WebDriver Launch_browser(String Browser,String url)
	{
		String path = "src\\test\\resources\\DRIVERS\\chromedriver.exe";
		String path1 = "src\\test\\resources\\DRIVERS\\geckodriver.exe";
		if(Browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", path);
			dr=new ChromeDriver();
		}
		else if(Browser.contains("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", path1);
			dr=new FirefoxDriver();
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	
	

}
