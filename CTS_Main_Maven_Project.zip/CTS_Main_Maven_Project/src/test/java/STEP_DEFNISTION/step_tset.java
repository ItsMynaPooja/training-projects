package STEP_DEFNISTION;

import org.openqa.selenium.WebDriver;

import BASE_CLASSES.Utilities;
import EXCEL_UTILITIES.Excel_io;
import POM_PAGES.page_2_signin;
import POM_PAGES.page_3_cruises;
import POM_PAGES.page_4_home;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class step_tset
{
	WebDriver dr;
	//Excel_io e_obj;
	Utilities obj;
	page_2_signin p2;
	page_3_cruises p3;
	page_4_home p4;
	
	String url="http://newtours.demoaut.com/mercurysignon.php";
	
	@Given("^lanuch the browser$")
	public void lanuch_the_browser() throws Throwable 
	{
		System.out.println("launch browser");
		obj=new Utilities();
		dr=obj.Launch_browser("chrome", url);          
	}

	@When("^enter UID and PWD do login$")
	public void enter_UID_and_PWD_do_login() throws Throwable 
	{
		p2=new page_2_signin(dr);
		p3=new page_3_cruises(dr);
		p4=new page_4_home(dr);
		//e_obj =new Excel_io();
		//e_obj.get_test_data();
		p2.p2_method("PoojaMars","gergalmars");
		
		p3.Data();
		p4.h_table();
		
	}

	@Then("^succesfull login happened$")
	public void succesfull_login_happened() throws Throwable 
	{
     System.out.println("pass");
	}

}
