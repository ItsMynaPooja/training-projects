package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import BASE_CLASSES.Wait_Screenshot;

public class page_4_home {
	WebDriver dr;
	Wait_Screenshot wt;
	
public  page_4_home(WebDriver dr)
{
	this.dr=dr;
	wt=new Wait_Screenshot(dr);
}

public void home()
{
	By reg_b =By.xpath("//tr[@class='mouseOut'][1]//td[2]//a");
//	WebElement wt_log=wt.waitForElement(reg_b, 20);
//	wt_log.click();
	dr.findElement(reg_b).click();
}

public void h_table()
{	
	this.home();
	for(int r=1;r<=5;r++)
	{
		for(int c=1;c<3;c++)
		{
			By val =By.xpath("//td[@height='101']//tbody//tr["+r+"]//td["+c+"]");
		    String data=dr.findElement(val).getText();
			System.out.print(data +" ");
		}
		System.out.println();
	}
}
	
	
	

}
