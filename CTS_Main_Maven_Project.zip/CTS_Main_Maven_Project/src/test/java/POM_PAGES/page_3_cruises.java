package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSES.Wait_Screenshot;

public class page_3_cruises {
	WebDriver dr;
	Wait_Screenshot wt;
	
public  page_3_cruises(WebDriver dr)
{
	this.dr=dr;
	wt=new Wait_Screenshot(dr);
}

public void crusis()
{
	By reg_b =By.xpath("//tr[@class='mouseOut'][5]//td[2]/a");
//	WebElement wt_log=wt.waitForElement(reg_b, 20);
//	wt_log.click();
	dr.findElement(reg_b).click();
}

public void Data()
{
	this.crusis();
	By val =By.xpath("//tr[@class='style2'][6]//td[2]//font");
//	WebElement wt_log=wt.waitForElement(reg_b, 20);
//	wt_log.click();
	String data=dr.findElement(val).getText();
	System.out.println("The Extracted data is "+data);			
}


}
