package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSES.Wait_Screenshot;

public class page_1_register {
	Wait_Screenshot wt;
	
	WebDriver dr;
	
	
	public void page2_signin(WebDriver dr)
	{
		this.dr=dr;
		wt=new Wait_Screenshot(dr);
	}

	
	public void r_btn()
	{
		By reg_b =By.xpath("//td[@bgcolor='#FF9900']//table//tbody//tr//td[2]");
		WebElement wt_log=wt.waitForElement(reg_b, 20);
		wt_log.click();
		//dr.findElement(reg_b).click();
	}
	
	public void f_name(String f_n)
	{
		By fn =By.xpath("//input[@name='firstName']");
		WebElement wt_log=wt.waitForElement(fn, 20);
		wt_log.sendKeys(f_n);
		//dr.findElement(fn).sendKeys();
	}
	public void l_name(String l_n)
	{
		By ln =By.xpath("//input[@name='lastName']");
		WebElement wt_log=wt.waitForElement(ln, 20);
		wt_log.sendKeys(l_n);
		//dr.findElement(ln).sendKeys();
	}
	public void phone(String p_h)
	{
		By ph =By.xpath("//input[@name='phone']");
		WebElement wt_log=wt.waitForElement(ph, 20);
		wt_log.sendKeys(p_h);
		//dr.findElement(ph).sendKeys();
	}
	public void em(String eml)
	{
		By email =By.xpath("//input[@name='userName']");
		WebElement wt_log=wt.waitForElement(email, 20);
		wt_log.sendKeys(eml);
		//dr.findElement(email).sendKeys();
	}
	public void A_1(String add1)
	{
		By ad1 =By.xpath("//input[@name='address1']");
		WebElement wt_log=wt.waitForElement(ad1, 20);
		wt_log.sendKeys(add1);
		//dr.findElement(ad1).sendKeys();
	}

	public void A_2(String add2)
	{
		By ad2 =By.xpath("//input[@name='address2']");
		WebElement wt_log=wt.waitForElement(ad2, 20);
		wt_log.sendKeys(add2);
		//dr.findElement(ad2).sendKeys();
	}

	public void City(String cty)
	{
		By city =By.xpath("//input[@name='city']");
		WebElement wt_log=wt.waitForElement(city, 20);
		wt_log.sendKeys(cty);
		//dr.findElement(city).sendKeys();
	}

	public void State(String stt)
	{
		By st =By.xpath("//input[@name='state']");
		WebElement wt_log=wt.waitForElement(st, 20);
		wt_log.sendKeys(stt);
		//dr.findElement(st).click();
	}

	public void pin_c(String pin)
	{
		By pcode =By.xpath("//input[@name='postalCode']");
		WebElement wt_log=wt.waitForElement(pcode, 20);
		wt_log.sendKeys(pin);
		//dr.findElement(reg_b).click();
	}

	public void c_sel(String cnt )
	{
		By ind =By.xpath("//select[@name='country']");
		WebElement wt_log=wt.waitForElement(ind, 20);
		wt_log.sendKeys(cnt);
		//dr.findElement(reg_b).click();
	}

	public void country(String c_name )
	{
		By ind =By.xpath("//option[@value='92']");
		WebElement wt_log=wt.waitForElement(ind, 20);
		wt_log.sendKeys(c_name);
		//dr.findElement(reg_b).click();
	}
	
	public void u_name(String usr)
	{
		By un =By.xpath("//input[@id='email']");
		WebElement wt_log=wt.waitForElement(un, 20);
		wt_log.sendKeys(usr);
		//dr.findElement(un).click();
	}

	public void p_w(String pw)
	{
		By pwd =By.xpath("//input[@name='password']");
		WebElement wt_log=wt.waitForElement(pwd, 20);
		wt_log.sendKeys(pw);
		//dr.findElement(pwd).sendKeys(pw);
	}

	public void c_p(String c)
	{
		By cp =By.xpath("//input[@name='confirmPassword']");
		WebElement wt_log=wt.waitForElement(cp, 20);
		wt_log.sendKeys(c);
		//dr.findElement(cp).sendKeys(c);
	}

	public void s_btn(String sb)
	{
		By cp =By.xpath("//input[@name='register']");
		WebElement wt_log=wt.waitForElement(cp, 20);
		wt_log.sendKeys(sb);
		//dr.findElement(cp).sendKeys(sb);
	}
	

}
