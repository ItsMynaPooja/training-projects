package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSES.Wait_Screenshot;

public class page_2_signin {
	WebDriver dr;
	Wait_Screenshot wt;
	
public  page_2_signin(WebDriver dr)
{
	this.dr=dr;
	wt=new Wait_Screenshot(dr);
}

 public void u_name(String usr)
 {
	 By un= By.xpath("//input[@name='userName']");
		WebElement wt_log=wt.waitForElement(un, 20);
		wt_log.sendKeys(usr);
 }
 
 public void pwd(String ps)
 {
	By pw= By.xpath("//input[@name='password']");
	WebElement wt_log=wt.waitForElement(pw, 20);
	wt_log.sendKeys(ps);
 }
 
 public void s_b()
 {
	By pw= By.xpath("//input[@value='Login']");
	WebElement wt_log=wt.waitForElement(pw, 20);
	wt_log.click();
 }
 public void p2_method(String u,String p)
 {
	 this.u_name(u);
	 this.pwd(p);
	 this.s_b();
 }
 
 public String invalid()
 {
	String log= dr.findElement(By.xpath("//td[@bgcolor='#FF9900']//tr//td[1]/a")).getText();
	return log;
 }

}
