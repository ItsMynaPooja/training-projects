package POM_TestNG;

import org.testng.annotations.Test;

import BASE_CLASSES.Utilities;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class NewTest extends Utilities
{
	Utilities lb;
	String url="http://newtours.demoaut.com/index.php";
	
	
  @Test
  public void f() 
  {
System.out.println("test");
  }
  
  
//  @BeforeMethod
//  public void beforeMethod() 
//  {
//  }

  @BeforeClass
  public void beforeClass()
  {
	  get_test_data();
	  lb=new Utilities();
	  dr=lb.Launch_browser("chrome", url); 
  }
  
  @DataProvider
  public String[][] dp()
  {
	  return testdata;
  }

  @AfterClass
  public void afterClass() 
  {
  }

}
