package case_study1_package;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class case_study_class {
	WebDriver dr;	
	String act_eml;
	
//	}
//	  public void launch_browser() 
//	  {
//		  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
//			 dr = new ChromeDriver();
//			dr.get("http://demowebshop.tricentis.com/");
//		
//	  }
		public static String filename="C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\p1\\case_study.xlsx",
                sheetname="Sheet1";
  public static String[][] testdata;
  public static int r_no,c_no;
  
  
  public static void get_Test_data(){
  testdata=new String[2][7];
  int c;String s=null,s1=null,s2=null;
		for(r_no=0;r_no<=1;r_no++)
		{
			
			try
			{
				for(c_no=0;c_no<7;c_no++)
				{
		System.out.println("in get test data row="+ r_no);
		File f= new File(filename);
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet =wb.getSheet(sheetname);
		XSSFRow row=sheet.getRow(r_no);
		
		XSSFCell cell1=row.getCell(c_no);
		testdata[r_no][c_no]=cell1.getStringCellValue();
		System.out.println("row 1:"+testdata[r_no][c_no]);
		
//		XSSFCell cell2=row.getCell(1);
//		testdata[r_no][1]=cell2.getStringCellValue();
//		System.out.println("row 1:"+testdata[r_no][1]);
//		
//		XSSFCell cell3=row.getCell(2);
//		testdata[r_no][2]=cell3.getStringCellValue();
//		System.out.println("row 1:"+testdata[r_no][2]);
//		
//		XSSFCell cell4=row.getCell(3);
//		testdata[r_no][3]=cell4.getStringCellValue();
//		System.out.println("row 1:"+testdata[r_no][3]);
//		
//		XSSFCell cell5=row.getCell(4);
//		testdata[r_no][4]=cell5.getStringCellValue();
//		System.out.println("row 1:"+testdata[r_no][4]);
//		
//		XSSFCell cell6=row.getCell(5);
//		testdata[r_no][5]=cell6.getStringCellValue();
//		System.out.println("row 1:"+testdata[r_no][5]);
		
		
			}
			}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}
		}
  
	
	public String reg(String Gender, String fn,String ln,String eid,String pwd,String cpwd)
	{
		  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			 dr = new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			
		dr.findElement(By.xpath("//a[@class='ico-register']")).click();
		dr.findElement(By.xpath("//input[@value='"+Gender+"']")).click();
		
		
		dr.findElement(By.xpath("//input[@id='FirstName']")).sendKeys(fn);
		dr.findElement(By.xpath("//input[@id='LastName']")).sendKeys(ln);
		dr.findElement(By.xpath("//input[@id='Email']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[@id='Password']")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@id='ConfirmPassword']")).sendKeys(cpwd);
		dr.findElement(By.xpath("//input[@id='register-button']")).click();

		try{
			act_eml=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
			
			File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
			File f2=new File("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\ss1\\in4.png");
			
			try {
				FileUtils.copyFile(f1,f2);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		catch(org.openqa.selenium.NoSuchElementException pooja)
		{
			act_eml=dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).getText();
			
			File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
			File f2=new File("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\scrnshot\\v4.png");
			
			try {
				FileUtils.copyFile(f1,f2);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	
		
		return act_eml;
	}

		
}
