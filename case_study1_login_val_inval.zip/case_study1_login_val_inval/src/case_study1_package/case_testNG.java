package case_study1_package;


import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class case_testNG extends case_study_class 
{
	WebDriver dr;
	case_study_class obj;
	
	 
  @BeforeClass
	  public void beforeClass() 
  {
	  System.out.println("bc");
	  get_Test_data();
  }
	  
	  @Test(dataProvider="login_data")
	  public void fromdp(String gender,String fname,String lname,String mail,String pw,String cpw,String exp) 
	  {
		obj = new case_study_class();
		String a_eid =obj.reg(gender,fname, lname, mail, pw, cpw);
		System.out.println("act_res:"+a_eid);
		   System.out.println("ex_res:"+exp);
			SoftAssert sa=new SoftAssert();
			sa.assertEquals(a_eid, exp);
			sa.assertAll();
	  }
		

	 @DataProvider(name="login_data")
		public String[][] provide_data()
		{
				 return testdata;
		 }
	 

}
