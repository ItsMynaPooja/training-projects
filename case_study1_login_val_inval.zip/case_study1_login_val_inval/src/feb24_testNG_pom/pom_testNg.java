package feb24_testNG_pom;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import feb24_POM.home_page_pom;
import feb24_POM.pom_login_java;

public class pom_testNg {
	WebDriver dr;
	pom_login_java loginpage;
	home_page_pom homepage;
	
	
	
  @Test(priority=0)
  public void test_login_page() 
  {
	  loginpage = new pom_login_java(dr);
	  String login_page_title = loginpage.get_title();
	 Assert.assertTrue(login_page_title.contains("Demo"));
  }
  
  
  @Test(priority=1)
  public void test_home_page()
  {
	  loginpage.do_login("poojacm3@gmail.com","gergal18");
	  homepage = new home_page_pom(dr);
	  String actual_val =homepage.get_displed_eid();
	  Assert.assertTrue(actual_val.contains("poojacm3@gmail.com"));
	  
  }
  
  
  
  @BeforeClass
  public void launch_browser() 
  {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
  }

}
