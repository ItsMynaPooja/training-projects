package logfiles;

import org.apache.log4j.Logger;

public class Logs {
	
	public static void main(String[] args)
	{
	Logger log= Logger.getLogger("devpinoyLogger");
	log.debug("Error!!!! Happended");
	log.info("Info Message");
	}
	
}
