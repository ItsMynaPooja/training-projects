package pets_pages_POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pets_Libraries.utilities_pets;

public class reg_page {
  WebDriver dr;
  utilities_pets wt;

  
  public reg_page(WebDriver dr)
  {
	  this.dr=dr;
	  wt=new utilities_pets(dr);
  }
  
 
  
  public void get_reg() 
  
  {
	  By Reg_in =By.xpath("//div[@id='Catalog']/a");
		WebElement wt_reg=wt.waitForElement(Reg_in, 20);
		wt_reg.click();
	 // dr.findElement(By.xpath("//div[@id='Catalog']/a")).click();

		wt.get_screenshot();
  }
  
	public String get_title()
	{
		return dr.getTitle();
	}
	
	public String final_msg()
	{
		By msg=By.xpath("//li[@class='success']");
		WebElement wt_msg=wt.waitForElement(msg, 20);
		String res=wt_msg.getText();
		wt.get_screenshot();
		return res;
	}
	
	public void log_in(String u)
	{
		By by_uname =By.xpath("//input[@name='username']");
		WebElement wt_log=wt.waitForElement(by_uname, 20);
		wt_log.sendKeys(u);
		
	}
	
	public void pwd(String p)
	{
		By by_pwd =By.xpath("//input[@name='password']");
		WebElement wt_pwd=wt.waitForElement(by_pwd, 20);
		wt_pwd.sendKeys(p);
	}
	public void btn()
	{
		By log_btn =By.xpath("//input[@id='login']");
		WebElement wt_btn=wt.waitForElement(log_btn, 20);
		wt_btn.click();
	}
	public void log(String us,String ps)
	{
		this.log_in(us);
		this.pwd(ps);
		this.btn();
		wt.get_screenshot();
	}
  
   }
