package wait_statements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class wait_login_source {
	WaitTypes wt;
	WebDriver dr;
	
	public wait_login_source(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void login(String uid,String pwd)
	{
		wt = new WaitTypes(dr);
		
		By by_uid = By.xpath("//input[@class='email']");
		WebElement wt_eid=wt.waitForElement(by_uid, 20);
		wt_eid.sendKeys(uid);
		
		By by_pwd = By.xpath("//input[@class='password']");
		WebElement wt_pwd=wt.waitForElement(by_pwd, 20);
		wt_pwd.sendKeys(pwd);
		
		By by_btn = By.xpath("//input[@value='Log in']");
		WebElement wt_btn=wt.waitForElement(by_btn, 20);
		wt_btn.click();
		
		
		
	}

}
