package feb_25_pom_pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pom_pfact_login {
	
	WebDriver dr;
	
	@FindBy(xpath="//input[@type='text']")
	WebElement uname;
	
	@FindBy(xpath="//input[@type='password']")
	WebElement pwd;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement btn;
	
	public  pom_pfact_login(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void set_name(String un)
	{
		uname.sendKeys(un);
	}
	
	public void set_pwd(String pw)
	{
		pwd.sendKeys(pw);
	}
	
	public void clk_btn()
	{
		btn.click();
	}
	
	
	public void do_login(String u,String p)
	{
		this.set_name(u);
		this.set_pwd(p);
		this.clk_btn();
		
	}
	public String get_title()
	{
		return dr.getTitle();
	}


}
