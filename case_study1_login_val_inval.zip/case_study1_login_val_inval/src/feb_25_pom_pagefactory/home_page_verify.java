package feb_25_pom_pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class home_page_verify {
	WebDriver dr;
	
	@FindBy(xpath="//div[@class='product_label']")
	WebElement prod;
	
	@FindBy(xpath="//div[@class='inventory_item'][1]//child::a[1]/div")
	WebElement prod_first;
	
	public  home_page_verify(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public String p_lable()
	{
     String lable=prod.getText();
     return lable;
	}
	
	public String p_name()
	{
     String name_first=prod_first.getText();
     return name_first;
	}


	
	

}
