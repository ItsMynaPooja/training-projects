package wait_testNG;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import wait_statements.wait_login_source;

public class NewTest {
	WebDriver dr;
	wait_login_source log_obj;
	
	@BeforeClass
	public void BC()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
			
		}
	
  @Test
  public void f() 
  {
	  log_obj=new wait_login_source(dr);
	  log_obj.login("poojacm3@gmail.com", "gergal18");
	  
  }
  
}
