package key_word_DD_framework;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String kw, loc,td;
		WebDriver dr = null;
		all_elements_funs we= new all_elements_funs(dr);
		excel_oparations excel=new excel_oparations();
		for(int r=1;r<=6;r++)
		{
			kw=excel.read_excel(r, 2);
			loc=excel.read_excel(r, 3);
			td=excel.read_excel(r, 4);
			
			switch(kw)
			{
			case "LaunchBrowser" :
				we.launchchrome(td);
				break;
				
			case "EnterText" :
				we.enter_text(loc, td);
				break;
				
			case "click" :
				we.click(loc);
				break;
				
			case "verify" :
				we.verify(loc, td);
				break;
			}
			
		}
		

	}

}
