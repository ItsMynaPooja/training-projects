package pets_tesNg;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pets_Libraries.utilities_pets;
import pets_pages_POM.base_functions;
import pets_pages_POM.home_page;
import pets_pages_POM.reg_page;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class NewTest_firefox {
	String url="https://jpetstore.cfapps.io/catalog";
	utilities_pets obj_utils;
	reg_page obj_reg;
	home_page obj_home;
	base_functions obj_base;
	WebDriver dr;
	
	  @BeforeClass
	  public void beforeClass() 
	  {
		  obj_utils = new utilities_pets(dr);
		 dr= obj_utils.launch_Browser("FIREFOX", url);
		  System.out.println("succesfull");
	  }
	
	  @Test
	  public void f1() 
	  { 
		  SoftAssert sa= new SoftAssert();
		  obj_home = new home_page(dr);
		  obj_home.signin();
		String home_title=obj_home.get_title();
		sa.assertTrue(home_title.contains("JPet")); 
		sa.assertAll();
	  }
	  
	  @Test
	  public void f2() 
	  {
		  SoftAssert sa= new SoftAssert();
		  obj_reg = new reg_page(dr);
		 // obj_reg.log("kavya", "kavyagergal");  // only login
		  obj_reg.get_reg();  //uncomment this  and last test for registraion 
		  String r_title= obj_reg.get_title();
		 sa.assertTrue(r_title.contains("JPet"));
		 sa.assertAll();
		
	  }
	  
	  @Test
	  public void f3()
	  {
		  obj_base = new base_functions(dr);
		  obj_base.do_reg("kalpana", "kavyagergal", "kavyagergal", "pooja", "c m", "ramyacm3@gmail.com", "1234567891", "bangalore", "tamilnadu", "hassan", "karnataka", "573201", "india");
			String fmsg=obj_reg.final_msg();
			obj_reg.log("kalpana", "kavyagergal");
			Assert.assertEquals(fmsg, "Your account has been created. Please try login !!");
	  }
	  
}
