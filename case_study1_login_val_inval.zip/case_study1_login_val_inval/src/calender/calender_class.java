package calender;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class calender_class {

	public static void main(String[] args) {
		WebDriver dr;
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
		String act_month_year="March 2020",cur_month_year;
		
		dr.findElement(By.xpath("//input[@type='text']")).click();
		
		cur_month_year = dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		
		
		while(!act_month_year.equals(cur_month_year))
		{
			dr.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
			cur_month_year = dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		}
		
		
		 List<WebElement>  all_dates=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
		 
		for(WebElement ele:all_dates)
		{
			String date=ele.getText();
			
	if(date.equalsIgnoreCase("17"))
	{
		ele.click();
	}
			
		}
			
	}

}
