package feb24_POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page_pom {
	WebDriver dr;
	
	By profile_xp = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	
	public home_page_pom(WebDriver dr)
	{
		this.dr =dr;
	}
	
	public String get_displed_eid()
	{
		return dr.findElement(profile_xp).getText();
	}

}
