package feb_25_pom_pagefac_testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import feb_25_pom_pagefactory.home_page_verify;
import feb_25_pom_pagefactory.pom_pfact_login;

import org.testng.annotations.BeforeClass;

public class pom_pagefact_testNg {
	
	WebDriver dr;
	pom_pfact_login obj_login;
	home_page_verify obj_verify;
	
	
  @Test(priority=0)
  public void test_login_page() 
  {
	  obj_login =new pom_pfact_login(dr);
	  String login_page_title = obj_login.get_title();
		 Assert.assertTrue(login_page_title.contains("Swag"));
  }
  
  @Test(priority=1)
  public void test_home_page()
  {
	  obj_login.do_login("standard_user","secret_sauce");
	  obj_verify=new home_page_verify(dr);
	  String actual_lable =obj_verify.p_lable();
	  Assert.assertTrue(actual_lable.contains("Products"));  
  }
  
  @Test(priority=2)
  public void test_home_page2()
  {
	  String actual_name =obj_verify.p_name();
	  System.out.println(actual_name);
	  Assert.assertTrue(actual_name.contains("Sauce"));  
  }
  
  
  
  @BeforeClass
  public void launch_browser() 
  {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
  }

}
