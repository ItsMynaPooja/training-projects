package selday1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class rbtn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
WebDriver dr =new ChromeDriver();
dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");


/*
List rb=dr.findElements(By.name("optradio"));   //here we have to inspect in the link and we have to salect parameter which is same in two radio buttons like id,name etc here we selected name.
((WebElement)rb.get(0)).click(); */               //typecasting firdt we have to type rb.get(0) no click option is available so we should add webelement then assign to a variable then we will get click option
                                                // value given inside the get is the indication of which radio button we have to press 0=male,1=female;

	
List rb=dr.findElements(By.name("gender"));   // second window in the same page selenium easy foe gender
((WebElement)rb.get(0)).click();

List rb1=dr.findElements(By.name("ageGroup"));  // for age group
((WebElement)rb1.get(1)).click();


dr.findElement(By.xpath(" ")).click();           //xpath of get values button

String s1=dr.findElement(By.xpath(" ")).getText();   // xpath of printed output values
System.out.println(s1);           // to print those values on the console.

	
	}

}
