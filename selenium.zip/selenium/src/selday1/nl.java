package selday1;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class nl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("enter the number: ");
//		Scanner scanner=new Scanner(System.in);
//		int s=scanner.nextInt();
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		dr.get("http://demowebshop.tricentis.com");
		String xp="//input[@value='Log in1']";
		String xp1="//input[@value='Log in']";
		WebElement we;
		
		WebDriverWait wt=new WebDriverWait(dr,20);
		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp1)));
		we.click();
		
		dr.findElement(By.linkText("Log in1")).click();
		dr.findElement(By.id("Email")).sendKeys("poojacm3@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("gergal18");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
	}

}
