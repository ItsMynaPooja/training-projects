package selday1;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Book{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the number: ");
		Scanner scanner=new Scanner(System.in);
		int s=scanner.nextInt();
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("poojacm3@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("gergal18");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		
		dr.findElement(By.xpath("//div[@class='header-menu']//child::li[1]/a")).click();
		
		for(int i=1;i<=7;i++)
		{
		
		if(i==s)
		{
			dr.findElement(By.xpath("//div[@class='item-box']["+i+"]")).click();
		}
		}
	String str=dr.findElement(By.xpath("//a[@class='product-name']")).getText();
	System.out.println(str);
	}

}
