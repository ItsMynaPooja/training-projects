package selday1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class listbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");  // program to change the date in the calender automatically
		WebDriver dr =new ChromeDriver();
		dr.get("https://examples.codecharge.com/Store/Default.php");

		WebElement we = dr.findElement(By.id("category_id"));
		Select sel= new Select(we);  //when u get red mark select selenium.out
		sel.selectByVisibleText("HTML & Web design");
	}

}
