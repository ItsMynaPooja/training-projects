package Action_package;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class drag_drop {

public static void main(String[] args) {
// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
 WebDriver dr=new ChromeDriver();
 dr.get("https://demoqa.com/droppable/");
 dr.manage().window().maximize();
 Actions bl=new Actions(dr);
 WebElement to=dr.findElement(By.xpath("//div[@id='droppable']"));
 WebElement from=dr.findElement(By.xpath("//div[@id='draggable']"));
 bl.dragAndDrop(from, to).perform();
 String textTo=to.getText();
 if(textTo.equals("Dropped!")) {
 System.out.println("Pass");
 }else
 System.out.println("Fail");
 

}


}
