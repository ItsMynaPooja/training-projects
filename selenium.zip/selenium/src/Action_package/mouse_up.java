package Action_package;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class mouse_up {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://retailm1.upskills.in/");
WebElement we = dr.findElement(By.xpath("//i[@class='fa fa-user-o']"));
Actions kb = new Actions(dr);
kb.moveToElement(we).build().perform();
	}

}
