package TestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class Bm_Am {
	  @Test
	  public void t1()
	  {
		  System.out.println("test t1");

	  }
	  
	  @Test 
	  public void t2()
	  {
		  System.out.println("test t2");
	  }
	  
	  @Test
	  public void t3()
	  {
		  System.out.println("test t3");
	  }
	  
  @BeforeMethod
  public void beforeMethod() 
  {
	  System.out.println("in BM");   //it will excute before each test case
  }

 @AfterMethod
 public void afterMethod()
 {
	 System.out.println("in AM");  //it will excute after each test case
  
 }

}
