package TestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import feb17.lgn_tstng_exmpl;

public class login_exmpl {
	
	lgn_tstng_exmpl jobj;
	
	 @BeforeMethod
	  public void beforeMethod()
	  {
		  jobj=new lgn_tstng_exmpl();
	  }
	
  @Test
  public void f() 
  {
	  jobj.login();
  }
  
}
