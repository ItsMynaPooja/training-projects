package TestNG;

import org.testng.annotations.Test;

public class NewTest3 {
  @Test(priority=2)  //if we want to execute particular test then we have to give priority.
  public void b()  //we can give any name if we are not giving priority then it will take the name in the alphabetical order
  {
	  System.out.println("test t1");

  }
  
  @Test(priority=1) //if we remove @Test it will not run we can call this inside some other test case then it will print but inly two test cases will excute.
  public void z()
  {
	  System.out.println("test t2");
  }
  @Test(priority=3)
  public void a()
  {
	  System.out.println("test t3");
  }
}
