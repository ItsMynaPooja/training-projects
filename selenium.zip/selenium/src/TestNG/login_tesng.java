package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

import feb17.sauc_login;

public class login_tesng {
	
	WebDriver dr;
	sauc_login obj;
	
	  @BeforeMethod
	  public void beforeMethod() 
	  {
		  
			System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			 dr = new ChromeDriver();
			dr.get("https://www.saucedemo.com/");
			obj = new sauc_login(dr);
	  }

  @Test
  public void t1() 
  {
	obj.login("standard_user", "secret_sauce");      //standard_user         //locked_out_user  secret_sauce
	                                                           
	
  }
  
  @Test
  public void t2() 
  {
	                                                         //standard_user         //locked_out_user  secret_sauce
	 obj.login("problem_user", "secret_sauce");                                                              
  }
                                                                  
  
  @AfterMethod
  public void afterMethod() 
  {
	  dr.close();
  }

}
