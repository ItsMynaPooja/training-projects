package feb18java;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	
	public class sauc_two_prd {

		WebDriver dr;
		public String exp_name1;
		 public String exp_price1;
		public String e_p1, act_price1;
		public String act_name1;
		 public float ep1;
		public float ap1;
		int count;
		
		
		public void login(String eid,String pwd)
		{
			dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
			dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
			dr.findElement(By.xpath("//input[@type='submit']")).click();
		}
		
		
		public sauc_two_prd(WebDriver dr)
		{
			this.dr=dr;
		}
		
		public void addpd(int n)
		{
			
			
		
		    exp_name1=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//div[2]//div")).getText();
		    System.out.println(exp_name1);
		     
		    exp_price1=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//div[3]//div")).getText();
			e_p1=exp_price1.substring(1,exp_price1.length());
//			ep1=Float.parseFloat(e_p1);
			System.out.println(e_p1);
				
				
				 dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::button")).click();
				 count++;
				 System.out.println(count);
				
				
				
				dr.findElement(By.xpath("//div[@id='shopping_cart_container']//child::a")).click();  //cart button
				
				act_name1=dr.findElement(By.xpath("//div[@class='cart_item']["+count+"]//child::a")).getText();
				System.out.println(act_name1);
				
				 act_price1=dr.findElement(By.xpath("//div[@class='cart_item']["+count+"]//child::div[2]//child::div[2]/div")).getText();
				 System.out.println(act_price1);
//				ap1=Float.parseFloat(act_price1);
//				System.out.println(ap1);
							
		
		}
		
//
//		public void verify( int j)
//		{
//			 
//			if((e_p1.compareTo(act_price1)==0)&&(exp_name1.compareTo(act_name1)==0))
//						
//				
//					
//						System.out.println("PASS");
//					
//					else
//						System.out.println("FAIL");
//						
//				 
//				
//		}
		

				public void Add_info()
				{
					  dr.findElement(By.xpath("//a[text()='CHECKOUT']")).click();
					  
					dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[1]")).sendKeys("Pooja");
					dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[2]")).sendKeys("C M");
					dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[3]")).sendKeys("573201");
					
					dr.findElement(By.xpath("//div[@class='checkout_buttons']//child::input")).click();
					dr.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();
				}
				
				
				public void Continue()
				{
					
					dr.findElement(By.xpath("//a[text()='Continue Shopping']")).click();
				
				}

				
		
		
	}


