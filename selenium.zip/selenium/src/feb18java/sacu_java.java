package feb18java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sacu_java {
	WebDriver dr;
	String exp_name1;
	String exp_price1;
	String e_p1;
	float ep1;
	
	
	public void login(String eid,String pwd)
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	
	
	public sacu_java(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void addpd(int n)
	{
		
		 dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::button")).click();
		 
	       exp_name1=dr.findElement(By.xpath("//a[@id='item_4_title_link']")).getText();
	       System.out.println(exp_name1);
	       
	       exp_price1=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::div[3]//child::div[1]")).getText();
			//System.out.println(exp_price1);
			
			 e_p1=exp_price1.substring(1,exp_price1.length());
			 //System.out.println(e_p1);
			ep1=Float.parseFloat(e_p1);
			System.out.println(ep1);
			
			
			
			dr.findElement(By.xpath("//div[@id='shopping_cart_container']//child::a")).click();
		
			
	
	}
	

	public void verify()
	{
		 
		String act_name1=dr.findElement(By.xpath("//div[@class='cart_item'][1]//child::a")).getText();
		System.out.println(act_name1);
		
		 String act_price1=dr.findElement(By.xpath("//div[@class='cart_item'][1]//child::div[2]//child::div[2]/div")).getText();
			//System.out.println(act_price1);
			float ap1=Float.parseFloat(act_price1);
			System.out.println(ap1);
			
			
			if((ep1==ap1))
					{
				if((exp_name1.compareTo(act_name1)==0))
				{
					System.out.println("PASS");
				}
				else
					System.out.println("FAIL");
					}
			
			 dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[2]")).click();
	}
	

			public void Add_info()
			{
				dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[1]")).sendKeys("Pooja");
				dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[2]")).sendKeys("C M");
				dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[3]")).sendKeys("573201");
				dr.findElement(By.xpath("//div[@class='checkout_buttons']//child::input")).click();
			}
			
	
	
}

	


	


