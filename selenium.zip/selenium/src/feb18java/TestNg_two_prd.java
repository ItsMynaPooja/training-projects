package feb18java;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.asserts.SoftAssert;

import feb17.sauc_login;
import feb18java.sacu_java;
import feb18java.sauc_two_prd;

public class TestNg_two_prd 
{
	WebDriver dr;
	sauc_two_prd obj;
	int c=0;
	int[] pn={2,1};
	

	
	  @BeforeClass
	  public void beforeClass() 
	  {
		  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		  
			 dr = new ChromeDriver();
			dr.get("https://www.saucedemo.com/");
			
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			
			obj = new sauc_two_prd(dr);
			obj.login("standard_user", "secret_sauce");
	  } 
	  
	 @BeforeMethod
	  public void beforeMethod() 
	 {
	obj.addpd(pn[c]);
	c++;
  }
	 
	 
	 @Test
    public void first() 
	 {
//		 obj.verify(1);
		  SoftAssert sa = new  SoftAssert();
		  sa.assertEquals(obj.exp_name1,obj.act_name1);
		  sa.assertEquals(obj.e_p1,obj.act_price1);
		  sa.assertAll();
	 }
	 
	 @Test
	    public void second() 
		 {
//			 obj.verify(2);
			 SoftAssert sa = new  SoftAssert();
			  sa.assertEquals(obj.exp_name1,obj.act_name1);
			  sa.assertEquals(obj.e_p1,obj.act_price1);
			  sa.assertAll();
		 }
		 
	 @AfterMethod
	 
	 public void AM()
	 {
	  if(c<2)
	  {
		  obj.Continue();
	 
	  }
	  
	 }

	 
  @AfterClass
  public void afterClass()
  {
	  obj.Add_info();
  }
}
