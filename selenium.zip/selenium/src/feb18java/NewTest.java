package feb18java;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

import feb17.sauc_login;
import feb18java.sacu_java;

public class NewTest 
{
	
//	int c=0;
//	int[] pn={2,1};
	
	WebDriver dr;
	sacu_java obj;
	
	
	  @BeforeClass
	  public void beforeClass() 
	  {
		  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			 dr = new ChromeDriver();
			dr.get("https://www.saucedemo.com/");
			dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			obj = new sacu_java(dr);
			obj.login("standard_user", "secret_sauce");
	  } 
	  
	 @BeforeMethod
	  public void beforeMethod() 
	 {
	obj.addpd(1);
	

	  }
	 
	 
	 @Test
    public void first() 
	 {
		 obj.verify();
	 }
	 
  @AfterClass
  public void afterClass()
  {
	  obj.Add_info();
  }
}
