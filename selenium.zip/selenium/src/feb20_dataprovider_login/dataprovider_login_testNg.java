package feb20_dataprovider_login;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.asserts.SoftAssert;

public class dataprovider_login_testNg {
	
	dataprovider_login	obj=new dataprovider_login();
	
  @Test(dataProvider = "login_data")
  
  public void testlogin(String eid, String pwd,String exp) 
  {
	  String act_val=obj.login(eid, pwd);
	  SoftAssert sa =new SoftAssert();
	  sa.assertEquals(act_val, exp);
	  sa.assertAll();
  }

  @DataProvider(name="login_data")
  public String[][] dp()
  			{
	  
	        String[][] data =  {
	        		            {"poojacm3@gmail.com","gergal18","poojacm3@gmail.com"},
	        		            {"poojacm3@gmail.com","gergal18","poojacm3@gmail.om"}  
		                       };
                     return data;
   
  }
}
