package feb20_dataprovider_login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class dataprovider_login {
	
	
	public String login(String eid,String pwd)
	{

		
			
			System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			WebDriver dr = new ChromeDriver();
			
			dr.get("http://demowebshop.tricentis.com");
			dr.findElement(By.linkText("Log in")).click();
			dr.findElement(By.id("Email")).sendKeys(eid);
			dr.findElement(By.id("Password")).sendKeys(pwd);
			dr.findElement(By.xpath("//input[@value='Log in']")).click();
			String val=dr.findElement(By.xpath("//div[@class='header-links']//child::a")).getText();
			dr.close();
			return val;
			
	}

}
