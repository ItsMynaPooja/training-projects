package feb14;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class excphtmllink {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		
		int qn;
		int  send_val=3;
		 String quantity;
	String title=dr.getTitle();
	System.out.println(title);
	
     String t2="Online Bookstore";
	if((title.compareTo(t2)==0))
	{
		System.out.println("pass");
	}
	else
	{
		System.out.println("fail");
	}
	
	dr.findElement(By.xpath("//select[@name='category_id']")).click();
	dr.findElement(By.xpath("//select[@name='category_id']//child::option[3]")).click();
	dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	dr.findElement(By.xpath("//td[@width='150']//child::img")).click();
	String web=dr.findElement(By.xpath("//td[@valign='top']//child::h1")).getText();
	System.out.println(web);
	String price=dr.findElement(By.xpath("//td[@valign='top']//child::td[2]")).getText();  //getting price value
	//System.out.println(price);
	String sub=price.substring(8,price.length());
	//System.out.println(sub);
	float p1=Float.parseFloat(sub);
	System.out.println("price value: "+p1);
	
	dr.findElement(By.xpath("//input[@name='quantity']")).clear();  //clearing value
	
	dr.findElement(By.name("quantity")).sendKeys("3");  //giving value
	dr.findElement(By.xpath("//input[@name='Insert1']")).click();  //click on add to cart after giving quantity
	
	String total=dr.findElement(By.xpath("//tr[@class='Row']//child::td[4]")).getText(); // taking total value in the next page
	//System.out.println(total);
	String subtotal=total.substring(1,total.length());
	//System.out.println(subtotal);
    float t1=Float.parseFloat(subtotal);
    System.out.println("the total price: "+t1);
	
	
 quantity=dr.findElement(By.xpath("//tr[@class='Row']//child::td/input")).getAttribute("value");
  System.out.println("the quantity:  "+quantity);
  qn=Integer.parseInt(quantity);
  
//  try
//  {
//	 quantity=dr.findElement(By.xpath("//tr[@class='Row']//child::td/input1")).getAttribute("value");
//	  System.out.println("the quantity:  "+quantity);
//	   qn=Integer.parseInt(quantity);
//	 
//  }
//  catch(org.openqa.selenium.NoSuchElementException p)
//  {
//	 System.out.println("i am exception here");
//	 qn=send_val;
//  }
  

  float mul=p1*qn;	
  
	if((mul==t1) &&(qn==send_val))
	{
		System.out.println("The price and quantity are varified");
	}
	else
	{
		System.out.println("price and Quantity mismatching");
	}
			
	
	
	}

}
