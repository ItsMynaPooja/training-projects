package feb17;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class scrnshot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("poojacm3@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("gergal18");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		
		//String val=dr.findElement(By.xpath("//div[@class='header-links']//child::a")).getText();
		File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2=new File("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\scrnshot\\pimg.png");
		try {
			FileUtils.copyFile(f1,f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
