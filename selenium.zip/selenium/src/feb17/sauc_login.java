package feb17;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class sauc_login {
	
	WebDriver dr;
	
	public void login(String eid,String pwd)
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
		
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	
	public sauc_login(WebDriver dr)
	{
		this.dr=dr;
	}
	

}
