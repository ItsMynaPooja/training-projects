package feb17;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class alert_msg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("pooja");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		
		try
		{
			Thread.sleep(3000);
		}
		catch(InterruptedException p)
		{
			p.printStackTrace();
		}
		
//		Alert a=dr.switchTo().alert();
//		String s=a.getText();
//		System.out.println(s);
//  	    a.accept();
//		
//		Alert a1=dr.switchTo().alert();
//		String s1=a1.getText();
//		System.out.println(s1);
//		a1.accept();
//		
		Alert a2=dr.switchTo().alert();
		String s2=a2.getText();
		System.out.println(s2);

		a2.dismiss();
		
	}

}
