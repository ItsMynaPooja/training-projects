package feb17;

public class lgn_tstng_exmpl 
{
	public void login()
	{
		System.out.println("login sucessfull");
	}

}
