package feb19_assert;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assert_NewTest {
	
	
  @Test
  public void t1() 
  {
	  String er="chennai",ar="chennai";
	  System.out.println("in test method t1");
	  SoftAssert sa = new  SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
  
  @Test
  public void t2() 
  {
	  String er="chennai",ar="chennai2";
	  System.out.println("in test method t1");
	  SoftAssert sa = new  SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
}
