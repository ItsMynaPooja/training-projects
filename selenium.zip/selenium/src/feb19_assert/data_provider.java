package feb19_assert;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class data_provider {
  @Test(dataProvider = "login")
  public void f(String eid, String pwd) 
  {
	  System.out.println("email id : " +eid+ " pwd : " +pwd);
  }

  @DataProvider(name="login")
  public String[][] dp()
  {
   String[][] data= {
		   
		             { "e1" ,"p1" },
		             { "e2", "p2" }
		             
                    };
		   
		   return data; 
    
   
  }
}
