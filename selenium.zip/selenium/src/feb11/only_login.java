package feb11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class only_login {
	
	public String login(String eid,String pwd)
	{

		
			
			System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			WebDriver dr = new ChromeDriver();
			
			dr.get("http://demowebshop.tricentis.com");
			dr.findElement(By.linkText("Log in")).click();
			dr.findElement(By.id("Email")).sendKeys(eid);
			dr.findElement(By.id("Password")).sendKeys(pwd);
			
			dr.findElement(By.xpath("//input[@value='Log in1']")).click();
			
			String er=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
	
		return er;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String em="poojacm3@gmail.com";
         String pw="pswdd";
		only_login obj1=new only_login();
		String er1= obj1.login(em, pw);
		 String s1=er1;
		 
		 if(er1.equals(s1)==true)
		 
			 System.out.println("pass");
			 else
				 System.out.println("fail");
		 
	}

}
