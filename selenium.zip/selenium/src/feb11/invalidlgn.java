package feb11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class invalidlgn {
	
	public String readexcel(String filename,String shtname,int r,int c)
	{
		String s = null;
		File f =new File(filename);
		try {
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(shtname);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			 s=cell.getStringCellValue();
			 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}

	public String writeexcel(String filename,String shtname, int r,int c,String input)
	{
		String s=null;
		File f=new File(filename);
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(shtname);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.createCell(c);
			cell=row.getCell(c);
			
			cell.setCellValue(input);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	
	public String login(String eid,String pwd)
	{

		
			
			System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			WebDriver dr = new ChromeDriver();
			
			dr.get("http://demowebshop.tricentis.com");
			dr.findElement(By.linkText("Log in")).click();
			dr.findElement(By.id("Email")).sendKeys(eid);
			dr.findElement(By.id("Password")).sendKeys(pwd);
			dr.findElement(By.xpath("//input[@value='Log in']")).click();
			String er=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
		return er;
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		invalidlgn c1=new invalidlgn();
		String fn="C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\p1\\inval.xlsx";
		String sn="Sheet1";
	
		
		String k=c1.readexcel(fn,sn,1,0);
		System.out.println(k);
		
		String m=c1.readexcel(fn,sn,1,1);
		System.out.println(m);
		
		String exp=c1.readexcel(fn,sn,1,2);
		System.out.println(exp);
		
		  
	    String actval=c1.login(k, m);
	    
	    String res;
	    if (actval.equals(exp)==true)
	    
	    	res="PASS";
	    
	    	else
	    		res="FAIL";
	    String wr=c1.writeexcel(fn,sn,1,3,actval);
	    String wr1=c1.writeexcel(fn,sn,1,4,res);
	
	}
		
	}


