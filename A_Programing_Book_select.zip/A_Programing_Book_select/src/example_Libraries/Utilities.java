package example_Libraries;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
	WebDriver dr;
	
	public Utilities(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebDriver Launch_Browser(String browser,String url)
	{
		switch(browser)
		{
		case "chrome":
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr=new ChromeDriver();
			break;
			
		case "firefox":
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
			break;
			
			default:
				System.out.println("available browsers are chrome and firefox");
				break;
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	

}
