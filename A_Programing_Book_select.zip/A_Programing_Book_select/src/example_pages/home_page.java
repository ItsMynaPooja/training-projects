package example_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page {
	WebDriver dr;
	
	public home_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void sel_book()
	{
		By program = By.xpath("//select[@name='category_id']//option[2]");
		dr.findElement(program).click();
	}
	
	public void srch_btn()
	{
		By search = By.xpath("//input[@name='DoSearch']");
		dr.findElement(search).click();
	}
	
	public void do_search()
	{
		this.sel_book();
		this.srch_btn();
	}
	
	 public String get_title()
	 {
		  return dr.getTitle();
	 }

	
	
}
