package example_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class next_page 
{
	WebDriver dr;
	
	public next_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String book_name()
	{
		By book_name = By.xpath("//tr[@class='Row'][3]//td[2]//a");
		String act_name=dr.findElement(book_name).getText();
		return act_name;
	}
	
	 public String  get_title()
	 {
		return  dr.getTitle();
	 }

}
