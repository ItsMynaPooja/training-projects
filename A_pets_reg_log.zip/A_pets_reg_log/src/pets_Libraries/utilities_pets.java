package pets_Libraries;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class utilities_pets {
	WebDriver dr;

	static int counter=1;
	
	
	public WebDriver launch_Browser(String browser,String url)
	{
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr =new ChromeDriver();
			break;
			
		
		case "FIREFOX":
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr =new FirefoxDriver();
			break;
		
		
		default:
			System.out.println("the available browsers are Chrome and FireFox");
			break;
			}
		
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	
	}
	
	public utilities_pets(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public WebElement waitForElement(By locator, int timeout)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			System.out.println("element located");
			return element;
		}catch(Exception e) {
			System.out.println("element not located" + e);
		}
		return null;
	}

	public WebElement elementToBeClickable(By locator, int timeout)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(dr, timeout);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			System.out.println("element located");
			return element;
		}catch(Exception e) {
			System.out.println("element not located" + e);
		}
		return null;
	}
	
	
	public void get_screenshot()
	{
		String path="C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\scrnshot";
		String filename=counter+ ".png";
		File f1 =((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+filename);
		
		try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("screenshot failed");
			e.printStackTrace();
		}
		counter++;
		
	}
	
	
}
