package pets_pages_POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import pets_Libraries.utilities_pets;

public class home_page {
	WebDriver dr;
	utilities_pets wt;
	
	
	public home_page(WebDriver dr)
	{
		this.dr=dr;
		wt =new utilities_pets(dr);
	}
	
	public void signin()
	{
		By sign_in =By.xpath("//div[@id='MenuContent']//a[2]");
		WebElement wt_home=wt.waitForElement(sign_in, 20);
		wt_home.click();

		wt.get_screenshot();
		System.out.println("yes");
	}
	
	public String get_title()
	{
		
		return dr.getTitle();
		
	}
}
