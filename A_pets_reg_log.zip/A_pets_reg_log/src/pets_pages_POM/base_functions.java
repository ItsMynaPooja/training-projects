package pets_pages_POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import pets_Libraries.utilities_pets;

public class base_functions {
	WebDriver dr;
	utilities_pets wt;
	
	public base_functions(WebDriver dr)
	{
		this.dr=dr;
		wt = new utilities_pets(dr);
	}
	
	public void do_reg(String ui,String pw,String cp,String fn,String ln,String email,String ph,String ad1,String ad2,String city,String state,String zip,String country)
	{
	
	By reg_one = By.xpath("//form[@action='/accounts/create']//tr[1]//child::td[2]//input");
	WebElement wt_eid=wt.waitForElement(reg_one, 20);
	wt_eid.sendKeys(ui);
	wt.get_screenshot();
	
	By reg_two = By.xpath("//form[@action='/accounts/create']//tr[2]//child::td[2]//input");
	WebElement wt_pw = wt.waitForElement(reg_two, 20);
	wt_pw.sendKeys(pw);
	
	By reg_three = By.xpath("//form[@action='/accounts/create']//tr[3]//child::td[2]//input");
	WebElement wt_cp = wt.waitForElement(reg_three, 20);
	wt_cp.sendKeys(cp);
	
	
	By reg_two_1 = By.xpath("//form[@action='/accounts/create']//div//tr[1]//input");
	WebElement wt_fn = wt.waitForElement(reg_two_1, 20);
	wt_fn.sendKeys(fn);
	
	By reg_two_2 = By.xpath("//form[@action='/accounts/create']//div//tr[2]//input");
	WebElement wt_ln = wt.waitForElement(reg_two_2, 20);
	wt_ln.sendKeys(ln);
	
	By reg_two_3 = By.xpath("//form[@action='/accounts/create']//div//tr[3]//input");
	WebElement wt_email = wt.waitForElement(reg_two_3, 20);
	wt_email.sendKeys(email);
	
	By reg_two_4 = By.xpath("//form[@action='/accounts/create']//div//tr[4]//input");
	WebElement wt_ph = wt.waitForElement(reg_two_4, 20);
	wt_ph.sendKeys(ph);
	
	By reg_two_5 = By.xpath("//form[@action='/accounts/create']//div//tr[5]//input");
	WebElement wt_ad1 = wt.waitForElement(reg_two_5, 20);
	wt_ad1.sendKeys(ad1);
	
	By reg_two_6 = By.xpath("//form[@action='/accounts/create']//div//tr[6]//input");
	WebElement wt_ad2 = wt.waitForElement(reg_two_6, 20);
	wt_ad2.sendKeys(ad2);
	
	By reg_two_7 = By.xpath("//form[@action='/accounts/create']//div//tr[7]//input");
	WebElement wt_city = wt.waitForElement(reg_two_7, 20);
	wt_city.sendKeys(city);
	
	By reg_two_8 = By.xpath("//form[@action='/accounts/create']//div//tr[8]//input");
	WebElement wt_state = wt.waitForElement(reg_two_8, 20);
	wt_state.sendKeys(state);
	
	By reg_two_9 = By.xpath("//form[@action='/accounts/create']//div//tr[9]//input");
	WebElement wt_zip = wt.waitForElement(reg_two_9, 20);
	wt_zip.sendKeys(zip);
	
	By reg_two_10 = By.xpath("//form[@action='/accounts/create']//div//tr[10]//input");
	WebElement wt_cntr = wt.waitForElement(reg_two_10, 20);
	wt_cntr.sendKeys(country);
	
	By reg_three_1 = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[1]//td[2]//select //option[2]");
	WebElement wt_lan = wt.waitForElement(reg_three_1, 20);
	wt_cntr.click();
	
	By reg_three_2 = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[2]//td[2]//select //option[5]");
	WebElement wt_fcat = wt.waitForElement(reg_three_2, 20);
	wt_fcat.click();
	
	By reg_three_3 = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[3]//td[2]//input[1]");
	WebElement wt_mlist = wt.waitForElement(reg_three_3, 20);
	wt_mlist.click();
	
	By reg_three_4 = By.xpath("//form[@action='/accounts/create']//table[2]//child::tr[4]//td[2]//input[1]");
	WebElement wt_mban = wt.waitForElement(reg_three_4, 20);
	wt_mban.click();
	
	By s_btn =By.xpath("//input[@id='save']");
	WebElement wt_sbtn= wt.waitForElement(s_btn, 20);
	wt_sbtn.click();
	}

	
	
	
}
