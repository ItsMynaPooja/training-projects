package day_4;

public class hdfc extends bank {
	
	public float get_roi()
	{
		return 8.5f;
	}
	

}
