package day_4;

import java.util.Scanner;

public class colfun {
 static String [][] std={{"01","pooja"},{"02","pallavi"},{"03","priya"},{"04","riz"}};
  static int [][] marks={{02,80,50,0},{01,25,70,0},{04,80,90,0},{03,90,50,0}};
    
    public int cal_avg(int i)
	{
			int avg=(marks[i][1]+marks[i][2])/2;
		
		return avg;
	}
    
 	

    public int search(String num)
	{
    	int s=Integer.parseInt(num);
    	int index =0;
		for(int j=0;j<=3;j++)
		{
			if(s == marks[j][0])
			{
				index=j;
				break;
			}
			}
		
		return index;
	}
	
	
    public String getname(String id )
    {
    	String n=null;
    	for(int i=0;i<=3;i++)
    	{
   
			if(id.equals(std[i][0]))
    				{
    			n=std[i][1];
    			System.out.println(n);
    			break;
    			
    				}
    	}
    	return n;
    }
   
  
    		
	public static void main(String[] args)
	{
		
		colfun o1=new colfun();
	/*	Scanner ip=new Scanner(System.in);
	    int p1=ip.nextInt();
	    int k = 0;*/
		 String s=o1.getname("02");
	   int m=o1.search("02");
	   int k=o1.cal_avg(m);
	  // String s=o1.getname("11");
		System.out.println("id" +" name "+" avg ");
		            System.out.println(marks[m][0]+ " "+s+ " "+k);
			           }
				
		
	}

		

		
	


