package day_4;

import java.util.Scanner;

public class strempl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] emp={{"e1","pooja"},{"e2","pallavi"},{"e3","priya"},{"e4","riz"}};
		int i,v;
		System.out.println("enter string");
		Scanner s =new Scanner(System.in);
		String s1=s.next();
		
		for(i=0;i<4;i++)
		{
			v=emp[i][0].compareTo(s1); 
			if(v==0)
		System.out.println(emp[i][1]);
		}
		
			}
			
			

}
