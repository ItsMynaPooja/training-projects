 package day_4;

public class Student
{
	int id;
	String name;
	int java;
	float avg;
  int selenium;
	
	public Student(int selenium,int java)
	{
		System.out.println("objected created");
		this.java=java;this.selenium=selenium;
	}
	void cal_avg(){
		avg=(selenium+java)/2.0f;
	}
}
