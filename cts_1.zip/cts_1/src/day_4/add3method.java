package day_4;

public class add3method {
//	
//	public int add(int x,int y)
//	{
//		
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

	}

}
