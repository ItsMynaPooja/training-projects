package DAY_1;

public class Pgm7 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int i=00;
		switch(i)
		{
		case 10:
		System.out.println("ten");
		break;
		case 20:
		System.out.println("twenty");
		break;
		case 30:
		System.out.println("thirty");
		break;
		case 40:
		System.out.println("fourty");
		break;
		default:
	System.out.println("no matches");
	break;
		}

	}

}
