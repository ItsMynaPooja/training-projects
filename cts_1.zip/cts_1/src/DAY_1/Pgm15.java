package DAY_1;

public class Pgm15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=1234,rem,count=0;
		while(n>0)
		{
			rem=n%10;
			count++;
			n=n/10;
		}
  System.out.println(count);
	}

}
