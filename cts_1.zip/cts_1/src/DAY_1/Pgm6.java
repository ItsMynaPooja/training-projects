package DAY_1;

public class Pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long sal=900000;
		float y1,y2,y3;
		long p1,p2,p3;
		float t1,t2,t3;
		if(sal<=180000)
		{
			 System.out.println("no tax");
		}
		 if((sal>=180001)&&(sal<=500000))

		{
			 p1=sal-180000;
			 y1=(0.1f*p1);
			// System.out.println("tax is " + p1);
			System.out.println("tax is 10% " + y1);
			
		}
		if((sal>=500001)&&(sal<=800000))
		{
			p2=sal-500000;
			 y2=(0.2f*p2);
			 p1=sal-180000;
			 y1=(0.1f*p1);
			 t2=y2+y1;
			 //System.out.println("tax is " + p2);
		 System.out.println("tax is " +t2);
			
		}
		 if(sal>800000)
		{
			p3=sal-800000;
			 y3=(0.3f*p3);
				p2=sal-500000;
				 y2=(0.2f*p2);
				 p1=sal-180000;
				 y1=(0.1f*p1);
			 t3=y3+y2+y1;
			 //System.out.println("tax is " + p3);
			System.out.println("tax is 20% " + t3);
			
		}	
	
	}

}
