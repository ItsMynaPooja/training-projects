package DAY_1;

public class Pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rem;
		int n=1234;
		
		int sum=0;
		
		while(n>0)
		{
			rem=n%10;
			sum=sum+rem;
			n=n/10;
			
			
		
		}
		System.out.println("the sum is "+sum);
			

	}

}
