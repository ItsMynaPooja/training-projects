package DAY_1;

public class Pgm8 {

	public static void main(String[] args) {
		int n=20,i,rem;
		for(i=1;i<=n;i++)
		{
			rem=i%2;
			if(rem==0)
				System.out.println("even num "+i);
		}
		
		

	}

}
