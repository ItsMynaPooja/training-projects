package DAY_1;

public class Pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=59138;
		int rem;
		int sum=0;
		while(n>0)
		{
			rem=n%10;
			if(rem>5)
			{
				sum=sum+rem;
			}
			n=n/10;
		}
		
System.out.println("the sum is "+sum);
	}

}
