package DAY_1;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int a = 10,b = 20,c = 5;
      if((a<b) && (a<c))
    	 
    	  {
    		  System.out.println(a +" a is smallest");
    	  }
    	  else  if((b<c) && (b<a))
    	   
    		  {
    			  System.out.println(b +" b is smallest");
    		  }
    	  
    	  else
    	  {
    		  System.out.println(c +" c is smallest");
    	  }
      }
      
	}

