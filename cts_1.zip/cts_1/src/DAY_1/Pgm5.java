package DAY_1;

public class Pgm5 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 int a = 2,b = 1,c = 4;
	      if(a<b)
	      {
	      if(a<c)
	      {
	    		  System.out.println(a +" a is smallest");
	      }
	      else
	      {
	    	  System.out.println(c +" c is smallest");
	      }
	      }
	      
	      else if(b<c)
	        {  		
	        	 System.out.println(b +" b is smallest");
	        
	        }
	      else
	      {
	    	  System.out.println(c +" c is smallest");
	      }
	    	 
	     		 
	}

}
