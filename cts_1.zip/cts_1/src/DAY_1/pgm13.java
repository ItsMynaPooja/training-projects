package DAY_1;

public class pgm13 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
	int n=10,f0=0,f1=1,f2,i;
System.out.println(f1);
for(i=1;i<n;i++)
{
	f2=f0+f1;
	System.out.println(f2);
	f0=f1;
	f1=f2;
}
	
	}

}
