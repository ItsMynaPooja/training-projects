package DAY_1;

public class Pgm17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,sum=0;
		i=15;
		while(i<=75)
		{
			if((i%7)==0)
			{
				System.out.println(i);
				sum=sum+i;
			}
			i++;
		}
		System.out.println(sum);

	}

}
