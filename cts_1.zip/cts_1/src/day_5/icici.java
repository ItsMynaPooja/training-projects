package day_5;

public class icici extends bank{
	
	public float get_roi()
	{
		return 9.5f;
	}

}
