package day_5;

public class test_interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		drawable d=new rectangle();
		d.draw();

	}

}
