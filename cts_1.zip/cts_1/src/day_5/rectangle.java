package day_5;

public class rectangle implements drawable {
	public void draw()
	{
		System.out.println("draw rectangle");
	}

}
