package day_5;

public class Student
{
	int id;
	String name;
	int selenium,java;
	float avg;
	
	public Student(String name,int id,int selenium,int java)
	{
		this.name=name;
		this.id=id;
		this.selenium=selenium;
		this.java=java;
		this.avg=avg;
	}
	
	void cal_avg()
	{
		avg=(selenium+java)/2.0f;
	}
}
