package day_5;

public interface drawable {
void draw();
}
