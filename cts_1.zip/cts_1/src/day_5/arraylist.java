package day_5;

import java.util.ArrayList;

public class arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> str_al = new ArrayList<String>();
		str_al.add("pooja");
		str_al.add("pallavi");
		str_al.add("priyanka");
		str_al.add("rizvana");
		
		System.out.println("before insertion"+str_al);
		str_al.add(1,"amma");
		System.out.println("after insertion"+str_al);
		str_al.remove("priyanka");
		System.out.println("after deletion"+str_al);
		str_al.remove(2);
		System.out.println("after deletion"+str_al);
		str_al.add("kavya");
		System.out.println("after insertion"+str_al);
		for(String s:str_al)
		{
			System.out.println(s);
		}
		
		ArrayList<Integer> s_al = new ArrayList<Integer>();
		s_al.add(12);
		s_al.add(45);
		s_al.add(78);
		s_al.add(14);
		
		System.out.println("before insertion"+s_al);
		s_al.add(1,20);
		System.out.println("after deletion"+s_al);

	}

}
