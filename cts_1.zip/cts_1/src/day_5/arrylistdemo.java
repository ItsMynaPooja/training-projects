package day_5;

import java.util.ArrayList;

public class arrylistdemo {
	
	ArrayList<Student> std_al = new ArrayList<Student>();
	
	public void create_al()
	{
		Student s1 =new Student("pooja ",845,90,90);
		Student s2 =new Student("pallavi ",846,80,80);
		std_al.add(s1);
		std_al.add(s2);
	}
	
	public void display_al()
	{
		for(Student s: std_al)
		{
			System.out.println("Name : " +s.name+",ID : "+s.id+",sel marks : "+s.selenium+",java marks : "+s.java);
					
		
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arrylistdemo n1=new arrylistdemo();
		n1.create_al();
		n1.display_al();

	}

}
