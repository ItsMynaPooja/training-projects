package day_5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;




public class noteread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

try {
	FileInputStream fis = new FileInputStream("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\note1.txt");
 
int i;
while((i = fis.read())!=-1)
{
	System.out.print((char)i);
}
fis.close();


FileOutputStream fos=new FileOutputStream("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\note1.txt");
byte[] d="I AM LERANING JAVA".getBytes();
fos.write(d);
fos.close();
} 

catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	
	}

}
