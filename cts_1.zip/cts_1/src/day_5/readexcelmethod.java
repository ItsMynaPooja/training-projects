package day_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readexcelmethod {
	
	public String readexcel(String filename, String shtname, int r, int c)
	{
		
	String s = null;
		File f =new File(filename);
		try {
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet(shtname);
			XSSFRow row = sh.getRow(r);
			XSSFCell cell = row.getCell(c);
		    s = cell.getStringCellValue();
		
		
		   /* cell.setCellValue("chennai");
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);*/
					
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
		
	}
	
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		readexcelmethod s1=new readexcelmethod();
		String k=s1.readexcel("C:\\Users\\BLTuser.BLT0203\\Desktop\\pcts\\pooja1.xlsx","Sheet1",2,5);
	System.out.println(k);
	}

}
