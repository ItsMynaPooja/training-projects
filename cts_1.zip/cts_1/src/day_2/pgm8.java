package day_2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=2,c;
int[] m={1,2,3,4};
try
{
	c=a/b;
	System.out.println(m[4]);
}
	catch(ArithmeticException ae)
	{
		System.out.println("catch of the arithmetic exception");
	}
catch(ArrayIndexOutOfBoundsException aie)
{
	System.out.println("catch of the ArrayIndexOutBoundException ");
}
	}

}
