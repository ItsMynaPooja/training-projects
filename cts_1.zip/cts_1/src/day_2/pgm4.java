package day_2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="Chennai",s1="Chennai",s2="chennai",s3;

int l= s.length();

int v=s.compareTo(s1);
System.out.println("length "+l+" return value "+v);

int vs=s.compareToIgnoreCase(s2);
System.out.println("rv "+vs);

 s3= s.substring(0,4);
 System.out.println("substring : "+s3);
 
 int p= s.indexOf("n",0);
 System.out.println("position  "+p);
 
 int p1=s.indexOf("n",p+1);
 System.out.println("position  "+p1);
	}

}
