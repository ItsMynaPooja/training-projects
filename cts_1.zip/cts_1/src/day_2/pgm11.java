package day_2;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num={21,34,91,59,16,44,29,74,49,82};
		int val,i,j;
		int sum=0;
		for(i=0;i<10;i++)
		{
			val=num[i];
			for(j=0;j<9;j++)
			{
				sum=val+num[j];
			}
			
				if(sum==65)
				{
					System.out.println("the sum is = "+sum);
				}
			
		}
		

	}

}
