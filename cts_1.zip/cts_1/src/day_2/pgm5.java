package day_2;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am learning core java";
		int p=0,i=0,c=0;
		while(p>=0)
		{
			p=s.indexOf(" ",i);
					c++;
			i=p+1;
		}
		System.out.println("the number words in this sentence are "+c);
		c=c-1;
System.out.println("the number of spaces are "+c);
	}

}
