package day_2;

public class pgm1 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int[] marks={95,91,16,50,27,01,81};
		int i;
		float sum=0;
		float avg;
		for(i=0;i<=6;i++)
		{
			sum=sum+marks[i];
		
		}
		System.out.println("the sum of the marks is "+sum);
		avg=sum/8;
		System.out.println("the avg is "+avg);
		if(avg>=70)
		{
			System.out.println("the grade is FCD");
		}
		else if((avg>=60)&&(avg<70))
		{
			System.out.println("the grade is FC");
		}
		else if((avg>=50)&&(avg<60))
		{
			System.out.println("the grade is SC");
		}
		else 
			System.out.println("the grade is PASS");

	}

}
