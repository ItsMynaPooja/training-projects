package day_2;

public class primenum {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 11,rem,x,flag=1;
		
		for(x=2;x<=num/2;x++)
		{
			rem=num%x;
			if(rem==0)
			{
				flag=0;
				break;
			}
				
			}
		if(flag==1)
		{
			System.out.println("the num is prime");
		}
		else
			System.out.println("the num is not prime");

	}

}
