package day_2;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,c = 0;
		int[] m={1,2,3,4};
		//System.out.println(c);
		try
		{
			System.out.println("print");
	    c=a/b;
		}
		catch(Exception e)
		{
			System.out.println("in the catch");
		}
		System.out.println(m[3]);

	}

}
