package day_2;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [][] m={{75,85,10},{80,90,95}};
int sum=0,r,c;
for(r=0;r<=1;r++)
{
	for(c=0;c<=2;c++)
	{
		if(m[r][c]%2==0)
		{
			sum=sum+m[r][c];
			
		}
	}
}
System.out.println(sum);
	}

}
