package day_2;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] marks={95,91,16,50,27,01,81};
		int i;
		float sum=0;
		for(i=0;i<=6;i=i+2)
		{
			if(marks[i]%2==1)
			{
				sum=sum+marks[i];
			}
		}
		System.out.println(sum);

	}

}
