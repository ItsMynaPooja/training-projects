package day_2;

public class pgm10 {

	public static void main(String[] args) {
		int[][] a={{1,1,1,1},{2,2,2,2},{3,3,3,3}};
		int[][] b={{1,1,1,1},{2,2,2,2},{3,3,3,3}};
		int[][] sum=new int[3][4];
		int r,c;
		for(r=0;r<3;r++)
		{
			for(c=0;c<4;c++)
			{
				sum[r][c]=a[r][c]+b[r][c];
				System.out.print(sum[r][c]+" ");
			}
			System.out.println();
		}
		// TODO Auto-generated method stub

	}

}
