package day_2;

public class phm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am learning core java",s2;
		int p1=0,i=0,p;
		while(p1>=0)
		{
			p1=s.indexOf(" ",i);
			p=p1;
			if(p==-1)
				p=s.length();
			System.out.println("i = "+i);
			System.out.println("p = "+p);
		    s2=s.substring(i,p);
		    System.out.println(s2);
			i=p+1;
		}


	}

}
