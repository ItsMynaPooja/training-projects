package day_2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] num={{18,4,-2,29},{-8,99,23,18},{199,67,309,47}};
		int r,c,max=0;
		
		for(r=0;r<=2;r++)
		{
			max=18;
			for(c=0;c<=3;c++)
			{
				
				if(max<num[r][c])
				{
					max=num[r][c];
				}
				
			}
			System.out.println(max);
		}
		

	}
}

