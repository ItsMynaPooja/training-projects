package day_3;

public class Student
{
	int id;
	String name;
	int testing,java;
	float avg;
	void cal_avg(){
		avg=(testing+java)/2.0f;
	}
}
