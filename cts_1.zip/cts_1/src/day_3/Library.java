package day_3;

public class Library {
	
	
	public int add(int x,int y) //we can also use void data type but in that case no need to write return bcz we are not returning any values to main 
	{
		int z=x+y;
		return z;
}
}