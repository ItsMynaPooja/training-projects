package day_3;

public class basiccal {
int num1=10,num2=10;

public int add(int num1,int num2)
{
	int x=num1+num2;
	return x;
}

public int sub(int num1,int num2)
{
	int y=num1-num2;
	return y;
}
}
