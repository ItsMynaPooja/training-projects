package day_3;

public class Calsi extends Library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Calsi c=new Calsi();
  int d=c.add(3, 5);
  System.out.println("addition: "+d);
  
	}

}
