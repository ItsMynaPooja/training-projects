package day_3;

public class Elephant extends Animal {
int lotrunk,lotusk;
public void display_details()
{
	super.display();
	System.out.println("lotrunk is="+lotrunk+", lotusk is="+lotusk);
}
}
