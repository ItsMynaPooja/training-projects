package day_3;
import java.util.Scanner;
public class pgm1 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
	int count=0;
	System.out.println("enter a charecters");
	Scanner pa=new Scanner(System.in);
	char s=pa.next().charAt(0);
	
	while(s!='n')
	{
		if((s == 'a'||s =='e'||s == 'i'|| s =='o'||s =='u'))
			//(s =='A')||(s =='E')||(s =='I')||(s =='O')||(s =='U'))
		{
			count++;
		}
		s=pa.next().charAt(0);
		
	}
	System.out.println("the count is "+count);
	}

}
