package day_3;

public class Animal {
int height,weight,age;
String color;
char gender;
public void display()
{
	System.out.println("the height is="+height+", weight is="+weight+", age is="+age+", color is="+color+", gender is="+gender);
	
}
}
