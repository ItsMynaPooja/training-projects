package day_3;

public class Zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Elephant e1=new Elephant();
		e1.height=8;
		e1.weight=200;
		e1.age=10;
		e1.gender='F';
		e1.color="grey";
		e1.lotrunk=2;
		e1.lotusk=1;
		e1.display_details();

	}

}
