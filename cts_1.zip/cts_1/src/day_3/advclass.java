package day_3;

public class advclass extends basiccal {
	
	public void mul()
	{
		int m=num1*num2;
		System.out.println(m);
	}
	
public static void main(String[] args) {
	// TODO Auto-generated method stub
	advclass n1=new advclass();
	n1.mul();
}
}
