package day_3;

public class College {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Student pooja=new Student();
		pooja.testing=80;
		pooja.java=90;
		pooja.cal_avg();
	System.out.println("the avg of pooja is "+pooja.avg);
	
		Student pallu=new Student();
		pallu.testing=80;
		pallu.java=70;
		pallu.cal_avg();
		System.out.println("the avg of pallu is "+pallu.avg);
		

	}

}
