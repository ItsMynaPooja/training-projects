package day_6;

public class addnum {
	static int[] num={18,2,99,23,77,46,32};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=0;
		for(int i=0;i<=6;i+=2)
		{
			if(num[i]%2==0)
				s=s+num[i];
		}
		System.out.println(s);
		

	}

}
